import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = json.loads((ROOT / 'analysis' / 'outputs' / 'dashboard_data.json').read_text())


class ProjectTests(unittest.TestCase):
    def test_primary_counts(self):
        self.assertEqual(DATA['core']['registered_customers'], 100000)
        self.assertEqual(DATA['core']['journey_sessions'], 895203)
        self.assertEqual(DATA['core']['successful_transactions'], 815964)

    def test_join_quality(self):
        self.assertEqual(DATA['quality']['transaction_sessions_missing_clickstream'], 2)
        self.assertEqual(DATA['quality']['transaction_customer_ids_missing_customer_table'], 0)
        self.assertGreater(DATA['quality']['successful_line_item_product_match_rate'], 0.999)

    def test_retention_ranges(self):
        for row in DATA['retention_curve']:
            self.assertGreaterEqual(row['rate'], 0)
            self.assertLessEqual(row['rate'], 1)
            self.assertLessEqual(row['retained'], row['buyers'])

    def test_adjustment_reduces_raw_gap(self):
        p = DATA['promo_comparison']
        self.assertLess(p['adjusted_gap_pp'], p['raw_gap_pp'])
        self.assertAlmostEqual(p['raw_gap_pp'], 3.6753614967, places=5)
        self.assertAlmostEqual(p['adjusted_gap_pp'], 0.5361680773, places=5)

    def test_site_assets_exist(self):
        for rel in ['index.html','assets/styles.css','assets/app.js','assets/dashboard_data.js','assets/preview.png']:
            self.assertTrue((ROOT / rel).exists(), rel)


if __name__ == '__main__':
    unittest.main()
